# IIT-AND-NIT-COLLEGE-PREDICATION-SYSTEM
IIT and NIT College Prediction System using PYTHON, Web Application, Database.
